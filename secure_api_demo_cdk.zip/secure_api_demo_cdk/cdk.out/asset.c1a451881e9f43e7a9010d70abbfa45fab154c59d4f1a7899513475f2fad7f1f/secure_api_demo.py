import json
import jwt
import datetime
import os

SECRET_KEY = os.environ.get("SECRET_KEY", "YHsdK+HO2kDAQwGVelwFpSdC8mY/oCQng3HMOdB1")

USERS = {
    "admin": {"password": "admin123", "role": "admin", "department": "finance"},
    "user": {"password": "user123", "role": "user", "department": "sales"}
}

def lambda_handler(event, context):
    path = event.get("rawPath", "")
    method = event.get("requestContext", {}).get("http", {}).get("method")
    headers = event.get("headers", {})
    body = json.loads(event.get("body", "{}") or "{}")
    query = event.get("queryStringParameters") or {}

    if path == "/login" and method == "POST":
        return login(body)
    elif path == "/admin-data" and method == "GET":
        return protected_route(headers, role_check="admin")
    elif path == "/department-data" and method == "GET":
        return department_route(headers, query)
    elif path.startswith("/user/") and method == "GET":
        username = path.split("/")[-1]
        return get_user_profile(headers, username)
    else:
        return response({"message": "Invalid route"}, 404)

def response(body, status=200):
    return {"statusCode": status, "body": json.dumps(body), "headers":{"Content-Type":"application/json"}}

def generate_token(username):
    payload = {
        "user": username,
        "role": USERS[username]["role"],
        "department": USERS[username]["department"],
        "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=30)
    }
    token = jwt.encode(payload, SECRET_KEY, algorithm="HS256")
    return token

def login(data):
    username = data.get("username")
    password = data.get("password")
    if username not in USERS or USERS[username]["password"] != password:
        return response({"message": "Invalid credentials"}, 401)
    token = generate_token(username)
    return response({"token": token})

def validate_token(headers):
    token = headers.get("authorization") or headers.get("Authorization")
    if not token:
        return None, {"message": "Token missing"}, 403
    try:
        decoded = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return decoded, None, None
    except jwt.ExpiredSignatureError:
        return None, {"message": "Token expired"}, 401
    except jwt.InvalidTokenError:
        return None, {"message": "Invalid token"}, 401

def protected_route(headers, role_check=None):
    user, err, code = validate_token(headers)
    if err: return response(err, code)
    if role_check and user["role"] != role_check:
        return response({"message": "Access denied — Admins only"}, 403)
    return response({"data": "Sensitive financial report"})

def department_route(headers, query):
    user, err, code = validate_token(headers)
    if err: return response(err, code)
    required_department = query.get("department")
    if user["department"] != required_department:
        return response({"message": "Access denied — Department mismatch"}, 403)
    return response({"data": f"Confidential data for {required_department} department"})

def get_user_profile(headers, username):
    user, err, code = validate_token(headers)
    if err: return response(err, code)
    if username not in USERS:
        return response({"message": "User not found"}, 404)
    return response({"username": username, "role": USERS[username]["role"]})
