# Path: run_api_demo.ps1
# Make sure you run this in your project root (where cdk.json is)

# -------------------------
# Step 1: Undeploy old stack
# -------------------------
Write-Host "Undeploying old stack..."
cdk destroy -f
Write-Host "Stack destroyed.`n"

# -------------------------
# Step 2: Deploy the stack
# -------------------------
Write-Host "Deploying stack..."
cdk deploy -O output.json
Write-Host "Stack deployed.`n"

# -------------------------
# Step 3: Set API URL
# -------------------------
$ApiUrl = "https://8p6p8rqufj.execute-api.us-east-1.amazonaws.com"
Write-Host "API URL set to: $ApiUrl`n"

# -------------------------
# Step 4: Login and get JWT token
# -------------------------
Write-Host "Logging in to get JWT token..."
$response = curl -Method POST "$ApiUrl/login" `
    -Headers @{"Content-Type"="application/json"} `
    -Body '{"username":"admin","password":"admin123"}' | ConvertFrom-Json

$token = $response.token
Write-Host "`nJWT Token: $token`n"

# -------------------------
# Step 5: Test Admin Data
# -------------------------
Write-Host "Testing /admin-data endpoint..."
curl -Method GET "$ApiUrl/admin-data" -Headers @{"Authorization"="$token"}
Write-Host "`n"

# -------------------------
# Step 6: Test Department Data
# -------------------------
Write-Host "Testing /department-data endpoint (finance)..."
curl -Method GET "$ApiUrl/department-data?department=finance" -Headers @{"Authorization"="$token"}
Write-Host "`n"

# -------------------------
# Step 7: Test User Profile (BOLA Demo)
# -------------------------
Write-Host "Testing /user/user endpoint..."
curl -Method GET "$ApiUrl/user/user" -Headers @{"Authorization"="$token"}
Write-Host "`n"

Write-Host "All tests completed successfully!"
