#!/usr/bin/env python3
import aws_cdk as cdk
from secure_api_demo_cdk.stack import SecureApiDemoStack

app = cdk.App()
SecureApiDemoStack(app, "SecureApiDemoStack")
app.synth()
