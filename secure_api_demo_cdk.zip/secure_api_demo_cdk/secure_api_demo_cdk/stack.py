from aws_cdk import (
    Stack,
    Duration,
    aws_lambda as _lambda
)
from constructs import Construct
from aws_cdk.aws_apigatewayv2_alpha import HttpApi, HttpMethod
from aws_cdk.aws_apigatewayv2_integrations_alpha import HttpLambdaIntegration

import os

class SecureApiDemoStack(Stack):
    def __init__(self, scope: Construct, construct_id: str, **kwargs):
        super().__init__(scope, construct_id, **kwargs)

        # Lambda function
        lambda_fn = _lambda.Function(
            self, "SecureApiLambda",
            runtime=_lambda.Runtime.PYTHON_3_9,
            handler="secure_api_demo.lambda_handler",
            code=_lambda.Code.from_asset(os.path.join("secure_api_demo_cdk", "lambda")),
            environment={"SECRET_KEY": "my_secret_key"},
        )

        # API Gateway HTTP API
        http_api = HttpApi(self, "SecureApiHttp")
        integration = HttpLambdaIntegration("LambdaIntegration", lambda_fn)

        routes = [
            {"path": "/login", "methods": ["POST"]},
            {"path": "/admin-data", "methods": ["GET"]},
            {"path": "/department-data", "methods": ["GET"]},
            {"path": "/user/{username}", "methods": ["GET"]}
        ]

        for r in routes:
            http_api.add_routes(
                path=r["path"],
                methods=[HttpMethod[m] for m in r["methods"]],
                integration=integration
            )

        self.api_url = http_api.api_endpoint
